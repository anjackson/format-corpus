CorkaM-OsX, a Mach-O/PDF/HTML/Java file

= Introduction =
it's simultaneously a valid:
 * OS X Mach-O binary (x86)
 * OS X compatible PDF
 * Oracle Java JAR (a CLASS inside a ZIP)
 * HTML page with JavaScript

it can be downloaded at http://code.google.com/p/corkami/downloads/list (binary's sha256: c2ef30573e4d61bbe4ebaba262391e6a8c955aa88c6375517033d67995df849f)

= About =
It serves no purpose, except proving that file formats not starting at offset 0 are a bad idea.

see http://mix.corkami.com for more details

Ange Albertini (@ange4771) - reverse engineer, author of Corkami
BSD licence, 2013
